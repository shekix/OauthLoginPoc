import { Component } from '@angular/core';
import { AuthService } from '../../auth.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {
  user: any;

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    // Retrieve the user profile (if available)
    this.user = this.authService.userProfile;
    setTimeout(() => {
      if (!this.authService.isLoggedIn)  {
        console.log('Not logged in, redirecting to login');
        this.router.navigate(['/login']);
      } else {
        this.user = this.authService.userProfile;
        console.log('Logged in user profile', this.user);
      }
    }, 1000);

  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }












  // ngOnInit(): void {
  //   // You might want to wait briefly for the token exchange to complete.
  //   setTimeout(() => {
  //     if (!this.authService.isLoggedIn) {
  //       this.router.navigate(['/login']);
  //     } else {
  //       this.user = this.authService.userProfile;
  //     }
  //   }, 1000);
  // }

  // logout(): void {
  //   this.authService.logout();
  //   this.router.navigate(['/login']);
  // }


}
