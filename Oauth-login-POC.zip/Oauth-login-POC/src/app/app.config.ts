import { ApplicationConfig, importProvidersFrom, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { OAuthModule } from 'angular-oauth2-oidc';
import { HttpClient, provideHttpClient } from '@angular/common/http';

import {
  MSAL_INSTANCE,
  MSAL_GUARD_CONFIG,
  MSAL_INTERCEPTOR_CONFIG,
  MsalService,
  MsalGuard,
  MsalBroadcastService,
  MsalInterceptor
} from '@azure/msal-angular';
import {
  MSALInstanceFactory,
  MSALGuardConfigFactory,
  MSALInterceptorConfigFactory
} from './msal-config';



export const appConfig: ApplicationConfig = {
  providers: [provideZoneChangeDetection({ eventCoalescing: true }), provideRouter(routes),
    provideHttpClient(),
    importProvidersFrom(
      OAuthModule.forRoot(), 
    ),
    { provide: MSAL_INSTANCE, useFactory: MSALInstanceFactory, deps: [] },

    // Register the MSAL Guard configuration
    { provide: MSAL_GUARD_CONFIG, useFactory: MSALGuardConfigFactory, deps: [] },

    // Register the MSAL Interceptor configuration
    { provide: MSAL_INTERCEPTOR_CONFIG, useFactory: MSALInterceptorConfigFactory, deps: [] },

    MsalService,
    MsalGuard,
    MsalBroadcastService,
  ]
};
