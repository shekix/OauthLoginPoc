// src/app/microsoft-auth-config.ts
import { AuthConfig } from 'angular-oauth2-oidc';

export const microsoftAuthConfig: AuthConfig = {
  // Microsoft identity platform issuer.
  // For multi-tenant apps, you can use 'common' (or 'consumers' for personal accounts only)
  issuer: 'https://login.microsoftonline.com/common/v2.0',

  // The URL to which Microsoft will redirect after authentication.
  redirectUri: window.location.origin + '/dashboard',

  // Your Microsoft Application (client) ID from the Azure Portal.
  clientId: '1c06bebb-698e-46a3-a5cd-fb06a9e46d68',

  // Scopes requested. You may add other scopes as needed.
  scope: 'openid profile email',

  // Using authorization code flow with PKCE.
  responseType: 'code',


  // You may set this to true for debugging purposes.
  showDebugInformation: true,

  // Disable strict discovery document validation in development.
  strictDiscoveryDocumentValidation: false,
};
