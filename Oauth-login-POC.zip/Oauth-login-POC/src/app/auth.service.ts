import { Injectable } from '@angular/core';
import { OAuthService } from 'angular-oauth2-oidc';
import { googleAuthConfig } from './auth-config';

import { MsalService } from '@azure/msal-angular';
import { Router } from '@angular/router';
import { AuthenticationResult } from '@azure/msal-browser';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

// //works fine
//   constructor(private oauthService: OAuthService,private msalService: MsalService) {

//     //this.oauthService.configure(microsoftAuthConfig);
//     this.oauthService.configure( googleAuthConfig);
//     this.oauthService.loadDiscoveryDocumentAndTryLogin()
//     .then(() => {
//       console.log('Discovery document loaded');
//       if (this.oauthService.hasValidAccessToken()) {
//         console.log('Successfully logged in!');
//       } else {
//         console.log('No valid access token yet.');
//       }
//     })
//     .catch(err => console.error('Error during discovery document load or login', err));
  
//     console.log('Starting code flow login...');
// }

//   public loginWith(config: string): void {
//     if (config === 'google') {
//       this.oauthService.configure(googleAuthConfig);
//       console.log("configure google");
      
//     } 

//   this.oauthService.loadDiscoveryDocumentAndTryLogin()
//   .then(() => {
//     console.log('Discovery document loaded');
//     if (this.oauthService.hasValidAccessToken()) {
//       console.log('Successfully logged in!');
//     } else {
//       console.log('No valid access token yet.');
//     }
//   })
//   .catch(err => console.error('Error during discovery document load or login', err));

//   console.log('Starting code flow login...');
//   //Initiates the OAuth login flow using the implicit flow.
//   //(For production, consider using Authorization Code Flow with PKCE.)
//   this.oauthService.initCodeFlow();
//   }

//   logout(): void {
//     this.oauthService.logOut();
//   }

//   get isLoggedIn(): boolean {
//     return this.oauthService.hasValidAccessToken();
//   }

//   get userProfile() {
//     return this.oauthService.getIdentityClaims();
//   }








constructor(
  private oauthService: OAuthService,
  private msalService: MsalService,
  private route:Router
) {
  // Configure Google OAuth at startup
  this.oauthService.configure(googleAuthConfig);
  this.oauthService.loadDiscoveryDocumentAndTryLogin()
    .then(() => {
      console.log('Google discovery document loaded');
    })
    .catch(err => console.error('Google discovery error', err));
}

// Login method for both providers
public loginWith(provider: 'google' | 'microsoft'): void {
  if (provider === 'google') {
    console.log('Starting Google login...');
    // Reconfigure Google OAuth if needed and start login flow
    this.oauthService.configure(googleAuthConfig);
    this.oauthService.loadDiscoveryDocumentAndTryLogin()
      .then(() => {
        this.oauthService.initCodeFlow();
      })
      .catch(err => console.error('Google login error', err));
  } else if (provider === 'microsoft') {
    this.msalService.loginPopup({ scopes: ['user.read'] })
    .subscribe({
      next: (response: AuthenticationResult) => {
        console.log('Microsoft login successful:', response);
        // Redirect to the dashboard upon successful login
        this.route.navigate(['/dashboard']);
      },
      error: (err) => console.error('Microsoft login error:', err)
    });
    
  }
}

logout(): void {
  // Log out from both providers (if needed)
  const googleUser = this.getGoogleUser();
  const msalUser = this.getMicrosoftUser();

  if (googleUser && !msalUser) {
    console.log('Logging out from Google');
    this.oauthService.logOut();
  } else if (msalUser && !googleUser) {
    console.log('Logging out from Microsoft');
    this.msalService.logoutPopup();
  }
}

// Get Google user if available
getGoogleUser(): any {
  if (this.oauthService.hasValidAccessToken()) {
    return this.oauthService.getIdentityClaims();
  }
  return null;
}

// Get Microsoft user if available
getMicrosoftUser(): any {
  const accounts = this.msalService.instance.getAllAccounts();
  if (accounts.length > 0) {
    return accounts[0];
  }
  return null;
}

// Combined user profile getter
get userProfile(): any {
  return this.getGoogleUser() || this.getMicrosoftUser();
}

get isLoggedIn(): boolean {
  return this.oauthService.hasValidAccessToken() || this.msalService.instance.getAllAccounts().length > 0;
}



}




