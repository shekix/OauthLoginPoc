import { Injectable } from '@angular/core';
import { OAuthService } from 'angular-oauth2-oidc';
import { googleAuthConfig } from './auth-config';
import { microsoftAuthConfig } from './microsoft-auth-config';
import { MsalService } from '@azure/msal-angular';
import { AuthenticationResult } from '@azure/msal-browser';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  //  constructor(private oauthService: OAuthService) {
  //   // Configure the OAuthService with Google settings.
  //   this.oauthService.configure(googleAuthConfig);
  //   // Load the discovery document and attempt login if the user is redirected back.
  //   //this.oauthService.loadDiscoveryDocumentAndTryLogin();
  //   this.oauthService.loadDiscoveryDocumentAndTryLogin()
  //     .then(() => {
  //       console.log('Discovery document loaded');
  //       if (this.oauthService.hasValidAccessToken()) {
  //         console.log('Successfully logged in!');
  //       } else {
  //         console.log('No valid access token yet.');
  //       }
  //     })
  //     .catch(err => console.error('Error during discovery document load or login', err));
  // }

  // // Initiate the login flow.
  
  // login() {
  //   console.log('Starting code flow login...');
  //   // Initiates the OAuth login flow using the implicit flow.
  //   // (For production, consider using Authorization Code Flow with PKCE.)
  //   this.oauthService.initImplicitFlow();
  // }

  // Sign out the user.
  // logout() {
  //   this.oauthService.logOut();
  // }

  // // Check if the user is logged in.
  // get isLoggedIn(): boolean {
  //   return this.oauthService.hasValidAccessToken();
  // }

  // // Optionally, you can get user information.
  // get userProfile() {
  //   return this.oauthService.getIdentityClaims();
  // }





  constructor(private oauthService: OAuthService,private msalService: MsalService) {

    //this.oauthService.configure(microsoftAuthConfig);
    this.oauthService.configure( googleAuthConfig);
    this.oauthService.loadDiscoveryDocumentAndTryLogin()
    .then(() => {
      console.log('Discovery document loaded');
      if (this.oauthService.hasValidAccessToken()) {
        console.log('Successfully logged in!');
      } else {
        console.log('No valid access token yet.');
      }
    })
    .catch(err => console.error('Error during discovery document load or login', err));
  
    console.log('Starting code flow login...');
}

  public loginWith(config: 'google' | 'microsoft'): void {
    if (config === 'google') {
      this.oauthService.configure(googleAuthConfig);
      console.log("configure google");
      
    } else if (config === 'microsoft') {
      this.oauthService.configure(microsoftAuthConfig);
      console.log("configured microsoft");
      
    }

  this.oauthService.loadDiscoveryDocumentAndTryLogin()
  .then(() => {
    console.log('Discovery document loaded');
    if (this.oauthService.hasValidAccessToken()) {
      console.log('Successfully logged in!');
    } else {
      console.log('No valid access token yet.');
    }
  })
  .catch(err => console.error('Error during discovery document load or login', err));

  console.log('Starting code flow login...');
  //Initiates the OAuth login flow using the implicit flow.
  //(For production, consider using Authorization Code Flow with PKCE.)
  this.oauthService.initCodeFlow();
  }

  logout(): void {
    this.oauthService.logOut();
  }

  get isLoggedIn(): boolean {
    return this.oauthService.hasValidAccessToken();
  }

  // get micrososftisLoggedin(): boolean{
  //   return this.msalService.instance.getAllAccounts().length > 0;
  // }

  // async microsoftLogin(){
  //   await this.msalService.instance.initialize();
  //   this.msalService.loginPopup().subscribe({
  //     next:(result:AuthenticationResult)=>{
  //       if(result.account){
  //         return ;
  //       }
         
  //     }
  //   });
  // }

  // microsoftLogout(): void {
  //   this.msalService.logoutRedirect({
  //     postLogoutRedirectUri: 'http://localhost:4200'
  //   });

  // }

  get userProfile() {
    return this.oauthService.getIdentityClaims();
  }






}
