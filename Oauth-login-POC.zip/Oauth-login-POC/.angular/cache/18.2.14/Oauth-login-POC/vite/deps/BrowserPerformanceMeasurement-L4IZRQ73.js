import {
  BrowserPerformanceMeasurement
} from "./chunk-WK4D357B.js";
import "./chunk-35ENWJA4.js";
export {
  BrowserPerformanceMeasurement
};
//# sourceMappingURL=BrowserPerformanceMeasurement-L4IZRQ73.js.map
